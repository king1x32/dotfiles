// ==UserScript==
// @name         VozLegend
// @version      2024-01-29
// @description  350tr, 1m8, 30cm
// @author       zollback
// @match        *://voz.vn/*
// @grant        none
// @run-at       document-start
// @noframes
// ==/UserScript==

(async function() {
    'use strict';
    // import('http://localhost:4173/assets/index.js')
    // console.log('Loaded');
    import('https://voz-legend.vercel.app/assets/index.js')
})()