// ==UserScript==
// @name                ChatGPT Infinity ∞
// @name:af             ChatGPT Oneindig ∞
// @name:ar             دردشةGPT إنفينيتي ∞
// @name:az             ChatGPT Sonsuzluq ∞
// @name:be             ChatGPT Бясконцасць ∞
// @name:bg             ChatGPT Безкрайност ∞
// @name:bn             ChatGPT ইনফিনিটি ∞
// @name:bo             ChatGPT དག་སྐྱེས་ཡོད་པ་ ∞
// @name:bs             ChatGPT Beskrajnost ∞
// @name:ca             ChatGPT Infinit ∞
// @name:ckb            ChatGPT نەپێندییە ∞
// @name:cs             ChatGPT Nekonečno ∞
// @name:cy             ChatGPT Anfeidredd ∞
// @name:da             ChatGPT Uendelighed ∞
// @name:de             ChatGPT Unendlichkeit ∞
// @name:dv             ChatGPT ނުވަތަ ބާވައްޖޭގެން ∞
// @name:dz             ChatGPT རྩེད་སྒྲིབ་གཉིས་ ∞
// @name:el             ChatGPT Άπειρο ∞
// @name:eo             ChatGPT Infinito ∞
// @name:es             ChatGPT Infinito ∞
// @name:et             ChatGPT Lõpmatus ∞
// @name:eu             ChatGPT Infinitua ∞
// @name:fa             ChatGPT بینهایت ∞
// @name:fi             ChatGPT Ääretön ∞
// @name:fo             ChatGPT Óendanlighed ∞
// @name:fr             ChatGPT Infini ∞
// @name:fr-CA          ChatGPT Infini ∞
// @name:gl             ChatGPT Infinito ∞
// @name:gu             ChatGPT અનંત ∞
// @name:haw            ChatGPT Māhina ʻole ∞
// @name:he             ChatGPT אינסוף ∞
// @name:hi             ChatGPT अनंत ∞
// @name:hr             ChatGPT Beskrajnost ∞
// @name:hu             ChatGPT Végtelenség ∞
// @name:hy             ChatGPT Անվերջ ∞
// @name:id             ChatGPT Infinity ∞
// @name:is             ChatGPT Óendanleiki ∞
// @name:it             ChatGPT Infinito ∞
// @name:ja             ChatGPT 無限 ∞
// @name:ka             ChatGPT უსასრულობა ∞
// @name:km             ChatGPT អនឡាញ ∞
// @name:kn             ChatGPT ಅನಂತ ∞
// @name:ko             ChatGPT 무한 ∞
// @name:ku             ChatGPT Pêşangeh ∞
// @name:ky             ChatGPT Ички ∞
// @name:la             ChatGPT Infinitas ∞
// @name:lb             ChatGPT Unendlechkeet ∞
// @name:lo             ChatGPT ບໍ່ໄປສູ່ຈັກຂອງສາມຫວ່າງ ∞
// @name:lt             ChatGPT Begalybė ∞
// @name:lv             ChatGPT Bezgalība ∞
// @name:mk             ChatGPT Бесконечност ∞
// @name:ml             ChatGPT അനന്തത ∞
// @name:mn             ChatGPT Тэгш бус ∞
// @name:mt             ChatGPT Infinità ∞
// @name:my             ChatGPT မြင်ကွင်း ∞
// @name:ne             ChatGPT अनंत ∞
// @name:nl             ChatGPT Oneindigheid ∞
// @name:no             ChatGPT Uendelighet ∞
// @name:pa             ChatGPT ਇਨਫਿਨਿਟੀ ∞
// @name:pl             ChatGPT Nieskończoność ∞
// @name:ps             ChatGPT لامکان ∞
// @name:pt             ChatGPT Infinito ∞
// @name:pt-BR          ChatGPT Infinito ∞
// @name:ro             ChatGPT Infinitate ∞
// @name:ru             ChatGPT Бесконечность ∞
// @name:si             ChatGPT අනන්තය ∞
// @name:sk             ChatGPT Nekonečno ∞
// @name:sl             ChatGPT Neskončnost ∞
// @name:so             ChatGPT Qaybtiisa ∞
// @name:sr             ChatGPT Бескрајност ∞
// @name:sv             ChatGPT Oändlighet ∞
// @name:ta             ChatGPT முடிவிலிருந்து ∞
// @name:te             ChatGPT అనంతత ∞
// @name:tg             ChatGPT Беоҳӣ ∞
// @name:th             ChatGPT อนันต์ ∞
// @name:ti             ChatGPT መደመር ∞
// @name:tk             ChatGPT Sonsuzluk ∞
// @name:tr             ChatGPT Sonsuzluk ∞
// @name:uk             ChatGPT Нескінченність ∞
// @name:ur             ChatGPT بے انتہا ∞
// @name:vi             ChatGPT Vô cùng ∞
// @name:yi             ChatGPT אינפיניטי ∞
// @name:zh             ChatGPT 无限 ∞
// @name:zh-CN          ChatGPT 无限 ∞
// @name:zh-HK          ChatGPT 無限 ∞
// @name:zh-SG          ChatGPT 无限 ∞
// @name:zh-TW          ChatGPT 無限 ∞
// @description         Generate endless answers from all-knowing ChatGPT (in any language!)
// @description:af      Genereer eindelose antwoorde van die alwetende ChatGPT (in enige taal!)
// @description:am      ሓበሬታይ ኣይነበርና መልእኽቲ ኣለኹም ኣሎኻዊ ያልኣይት ChatGPT (በቋንቋ!)
// @description:ar      قم بتوليد إجابات لا نهائية من ChatGPT المعرف بكل شيء (بأي لغة!)
// @description:az      Hər şeyi bilən ChatGPT-dən sonsuz cavablar yaradın (hər hansı bir dil ilə!)
// @description:be      Стварыце бясконцы адказы ад ўсеведучага ChatGPT (на любой мове!)
// @description:bem     Pamene mwaposa mafolosho a mʌnoze ChatGPT (mu lupiya lwa ndalama!)
// @description:bg      Генерирайте безкрайни отговори от всезнайния ChatGPT (на всяк език!)
// @description:bn      সর্বজ্ঞ চ্যাটজিপিটি থেকে অসীম উত্তর তৈরি করুন (যে কোন ভাষায়!)
// @description:bo      བཟོས་པ་བརྗོད་པའི་ChatGPTགི་གྲོས་པར་འགྲུབ་འདེམས་བསྐྱེད་མི་འོངས་པ། (ལས་སྐབས་ཀྱི་སྐད་ཡིག་གི་སྐད་!)
// @description:bs      Generišite beskonačne odgovore od sveznajućeg ChatGPT (na bilo kom jeziku!)
// @description:ca      Genereu respostes infinites des de l'omniscient ChatGPT (en qualsevol idioma!)
// @description:ceb     Sukdagon ang walay katapusan nga mga tubag gikan sa tanan-mahibaw-anong ChatGPT (sa bisan unsang pinulongan!)
// @description:ckb     پێشبینی چاتگپتەکە دیارییەکانی پێکراوەکان بنووسە (بە هەر زمانێکی دیکە!)
// @description:cs      Generujte nekonečné odpovědi od vševědoucího ChatGPT (v jakémkoli jazyce!)
// @description:cy      Cynhyrchwch atebion diddiwedd o ChatGPT y gŵr sy'n gwybod popeth (mewn unrhyw iaith!)
// @description:da      Generer endeløse svar fra den altvidende ChatGPT (på hvilket som helst sprog!)
// @description:de      Generieren Sie endlose Antworten von dem allwissenden ChatGPT (in beliebiger Sprache!)
// @description:dv      އެހެނދުކަޗެއްވެސީ ޗެއްސިސްޓޯނަށް ނިޔަލައިފައިވަނީ ސުރުކޮށް ފީހުން (ކަންއެވެސް ހަމަވެސް!)
// @description:dz      ཆགས་ཀྱིས་ལ་བརྟེན་གང་རུང་གི་ChatGPTགི་ཚོགས་པའི་སྐད་ཡིག་གྱི་སྐད་ཡིག་བྱེད་པ། (བླ་མའི་སྐད་ཡིག་!)
// @description:el      Δημιουργήστε ατελείωτες απαντήσεις από το γνώστη ChatGPT (σε οποιαδήποτε γλώσσα!)
// @description:eo      Kreu nesfinaĵajn respondojn el la ĉio-scianta ChatGPT (en ajn lingvo!)
// @description:es      Genera respuestas infinitas desde el ChatGPT omnisciente (¡en cualquier idioma!)
// @description:et      Loo lõputuid vastuseid kõike-teadvast ChatGPT-st (mis tahes keeles!)
// @description:eu      Sortu erantzun infinituak guztiz-arduratsuaren ChatGPT-tik (edozein hizkuntzan!)
// @description:fa      پاسخهای بیپایانی را از ChatGPT همهدانا تولید کنید (به هر زبانی!)
// @description:fi      Luo loputtomia vastauksia kaikkitietävästä ChatGPT:stä (millä tahansa kielellä!)
// @description:fo      Skapa endalaus svør frá altvitandi ChatGPT (á hvørjum málrøð!)
// @description:fr      Générez des réponses infinies à partir de ChatGPT qui sait tout (dans n'importe quelle langue!)
// @description:fr-CA   Générez des réponses infinies à partir de ChatGPT qui sait tout (dans n'importe quelle langue!)
// @description:gd      Cruthaich freagairtean gun crìoch à ChatGPT a tha a' faighneachd gach càil (ann an sam bith cànan!)
// @description:gl      Xere as respostas infinitas do ChatGPT que todo o sabe (en calquera lingua!)
// @description:gu      જ્ઞાનવાન ChatGPT થી અનંત જવાબો ઉત્પન કરો (કોઈ પણ ભાષામાં!)
// @description:haw     Haleleʻa i nā ʻōlelo pālulelo mai ke kupa ʻike loa o ChatGPT (i loko o kēlā ʻōlelo aku aʻe!)
// @description:he      יצרו תשובות אינסופיות מה-ChatGPT המבין הכל (בכל שפה!)
// @description:hi      सभी-जाननेवाले चैटजीपीटी से अनंत उत्तरों का उत्पादन करें (किसी भी भाषा में!)
// @description:hr      Generirajte beskrajne odgovore iz sveznajućeg ChatGPT-a (na bilo kojem jeziku!)
// @description:ht      Jenere repons san fen soti nan ChatGPT k-ap konnen tout bagay yo (nan nenpòt lang!)
// @description:hu      Végtelen válaszokat generáljon a mindentudó ChatGPT-ből (bármely nyelven!)
// @description:hy      Ստեղծեք անսահմանափակ պատասխաններ ամենագիտական ChatGPT-ից (ցանկացած լեզուն մեջ!)
// @description:id      Hasilkan jawaban tak terbatas dari ChatGPT yang tahu segalanya (dalam bahasa apa pun!)
// @description:is      Búið til endalaus svör frá allvissu ChatGPT (á hvaða tungumáli sem er!)
// @description:it      Genera risposte infinite dall'onnisciente ChatGPT (in qualsiasi lingua!)
// @description:ja      あらゆる言語で全知のChatGPTから無限の回答を生成します！
// @description:jv      Mbukak panggung jawaban saka ChatGPT kang suwénéh kabèh (kénging basa apapun!)
// @description:ka      შექმენით უსასრულო პასუხები ყველგანაწილებული ChatGPT-დან (ნელა ენაზე!)
// @description:kab     Kkes-as yidir seg yisem-asen n tafriqt ara ddunnit ChatGPT (di tifrat ara ddunit!)
// @description:kk      Барлық тілде бар білген ChatGPT-ден шексіз жауаптар жасау (қандай да тілде!)
// @description:km      បង្កើតចម្លើយមិនឃើញចប់ពី ChatGPT ដែលចែកសង្ស័យទាំងអស់ (ជាន់គ្រប់ភាសា!)
// @description:kn      ಎಲ್ಲರು ತಿಳಿದಿರುವ ಚಾಟ್ಜಿಪಿಟಿಯಿಂದ ಅನಂತ ಉತ್ತರಗಳನ್ನು ರಚಿಸಿ (ಯಾವುದೇ ಭಾಷೆಯಲ್ಲಿ!)
// @description:ko      어떤 언어로든지 무궁무진한 답변을 만들어내는 ChatGPT입니다!
// @description:ku      Ji ChatGPT-ê, ku hemî tiştan dizane, bersiva li serbazên li dor qewî yên hilbijartin (bi hertiştî zimanek!)
// @description:ky      Түз билимдүү ChatGPT боюнча чыгармаларды жаса
// @description:la      Genera infinitas responsiones de ChatGPT omniscio (in qualibet lingua!)
// @description:lb      Generéiert endlos Äntwerten vum allwëssende ChatGPT (op jiddere Sprooch!)
// @description:lo      ສ້າງຜົນສົດທີ່ສາມາດເລືອກຈາກພາສາທີ່ຮູ້ບຸກກຳລັງ ChatGPT (ໃນພາສາໃດໜຶ່ງ!)
// @description:lt      Sugeneruokite begalinį atsakymų kiekį iš visai žinoančio ChatGPT (bet kuria kalba!)
// @description:lv      Ģenerē nebeidzamus atbilžu variantus no vissapratīgā ChatGPT (jebkurā valodā!)
// @description:mg      Mandoza ny valiny miaraka amin'ny ChatGPT mahalala ny zavatra rehetra (amin'ny fiteny iray kokoa!)
// @description:mi      Whakapūmau i ngā whakautu kore mutunga mai i te ChatGPT matau i ngā reo katoa!
// @description:mk      Генерирајте безброј одговори од сèзнаената ChatGPT (на било кој јазик!)
// @description:ml      എന്നെഴുതാൻ അനന്യനായ ChatGPT (ഏതെങ്കിലും ഭാഷയിൽ) ഇന്നേക്കും വേണ്ടി അവസാനിപ്പിക്കുക!
// @description:mn      Сүүлд үлдсэнээсээ хайрцаг болох ChatGPT (ямар ч хэл дээр) дээрхээр ярих
// @description:ms      Cipta pelbagai jawapan daripada ChatGPT yang tahu segala-galanya (dalam apa-apa bahasa!)
// @description:mt      Iġġenera risposti infiniti mill-ChatGPT li kollha jaf (f'xi lingwa!)
// @description:my      အားလုံးကိုသင်ရိုးရိုးဆွဲနိုင်သည့် ChatGPT (တစ်ခုမှာယူသုံးရန်!)
// @description:ne      सबै-ज्ञानी ChatGPT बाट अनंत उत्तरहरू उत्पन्न गर्नुहोस् (कुनै पनि भाषामा!)
// @description:nl      Genereer eindeloze antwoorden van alwetende ChatGPT (in elke taal!)
// @description:no      Generer endeløse svar fra allvitende ChatGPT (på hvilket som helst språk!)
// @description:ny      Galimoto mabwino a mtendere zosiyanasiyana kuchokera ku ChatGPT woyankhula zonse! (muyankhulitsa chilichonse!)
// @description:pa      ਸਭ ਜਾਣ ਵਾਲੇ ChatGPT ਤੋਂ ਲੰਬੇ ਉੱਤਰਾਂ ਨੂੰ ਬਣਾਓ (ਕਿਸੇ ਵੀ ਭਾਸ਼ਾ ਵਿੱਚ!)
// @description:pap     Hasi respuesta sinfin di ChatGPT ku tur sabi (na kua idioma!)
// @description:pl      Generuj nieskończone odpowiedzi od wszechwiedzącego ChatGPT (w dowolnym języku!)
// @description:ps      د هغوی چټکال ChatGPT لخوا نهایت جوابونه جوړه کړئ (د هر یوه ژبه کی!)
// @description:pt      Gere respostas infinitas do ChatGPT onisciente (em qualquer idioma!)
// @description:pt-BR   Gere respostas infinitas do ChatGPT onisciente (em qualquer idioma!)
// @description:rn      Basha inzira nk'itandukanye z'uko ChatGPT uzi (mu rurimi rwose!)
// @description:ro      Generează răspunsuri infinite de la ChatGPT omniscient (în orice limbă!)
// @description:ru      Генерируйте бесконечные ответы от всезнающего ChatGPT (на любом языке!)
// @description:rw      Banda inama z'imirimo isigaye zose z'umuco wa ChatGPT (mu rurimi rwose!)
// @description:sg      Tia ngamana nga mbetela ti ChatGPT tozuwa mitayi mingi (po wundi ndimi yo ngambo!)
// @description:si      සියළු දැනටමත් සහතිකපත්කරන තවත් සිතියම් සැකසුම් ලබා දෙන්නාවූ ChatGPT සෑදීම (ඕනෑම භාෂාවෙන්ම!)
// @description:sk      Generujte nekonečné odpovede od vševietajúceho ChatGPT (v akomkoľvek jazyku!)
// @description:sl      Generirajte neskončne odgovore iz vsevednega ChatGPT (v katerem koli jeziku!)
// @description:sm      Faia se faiga tele i le ChatGPT eseese (i nisi gagana!)
// @description:sn      Simudza mhinduro dzakawanda kubva kune ChatGPT ichiwanikwa chisarudzo! (mune rimwe nguva!)
// @description:so      Kor u qaado jawaabo kala duwan oo ka soo saar ChatGPT (luuqad ka mid ah!)
// @description:sr      Генеришите безброј одговора од свемоћног ChatGPT (на било ком језику!)
// @description:sv      Generera oändliga svar från allvetande ChatGPT (på valfritt språk!)
// @description:sw      Toa majibu yasiyokuwa na mwisho kutoka kwa ChatGPT mwenye maarifa yote (katika lugha yoyote!)
// @description:ta      அனைத்து தகவலையும் அறியப்பட்ட சொந்தமான ChatGPT இலிருந்து முடிவுகளை உருவாக்கவும் (எந்த மொழியிலும்!)
// @description:te      అన్నింటినీకింట మాటలు రాయండి ChatGPT గురించి అనేక జవాబాలను సృష్టించండి (ఏదైనా భాషలో!)
// @description:tg      Ҷавобҳои бесуданни ChatGPTи ҳамаифақат (дар як забони муайяни!)
// @description:th      สร้างคำตอบไม่สิ้นสุดจาก ChatGPT ที่รู้ทุกสิ่ง (ในภาษาใดก็ได้!)
// @description:ti      ክርስትን ለማውጣት ከገጽታውን ChatGPT የተከሳሽ አስተካክል አስተካክሎት (በእውነት ቋንቋ!)
// @description:tk      Şeýle anlaşylýan ChatGPT (her hili üçin) arasyndan bäşmüňhat jawaplar döret
// @description:tn      Hlela zitsha zwine zwiṱhiselela kha ChatGPT vhufudziṱe (muvhili wo vha u ite!)
// @description:to      Fakatonutonu ʻihe ngāuekesi mei he ChatGPT fakaongoongo toenga (i he lea faka-Tonga ia!)
// @description:tpi     Sanapim hamamasples long save olsem ChatGPT i masples (long wanpela tok ples!)
// @description:tr      Bilge ChatGPT'den sonsuz cevaplar üret (herhangi bir dilde!)
// @description:uk      Генеруйте безкінечні відповіді від усезнаючого ChatGPT (на будь-якій мові!)
// @description:ur      سب جاننے والے ChatGPT سے لامتناہی جوابات پیدا کریں (کسی بھی زبان میں!)
// @description:uz      Barcha biladigan ChatGPT dan cheklovli javoblar oling (hech qanday tilda ham)!
// @description:vi      Tạo ra vô số câu trả lời từ ChatGPT thông minh (bằng bất kỳ ngôn ngữ nào!)
// @description:xh      Bhala izinto ezingekwaziyo eziyimfihlo kusuka ku ChatGPT (ngolwimi lwanyanetha!)
// @description:yi      דזשענערייט סאָף ענטפֿערס פֿון אַלע-געוויסן ChatGPT (אין קיין שפּראַך!)
// @description:zh      从无所不知的 ChatGPT 生成无穷无尽的答案 (用任何语言!)
// @description:zh-CN   从无所不知的 ChatGPT 生成无穷无尽的答案 (用任何语言!)
// @description:zh-HK   從無所不知的 ChatGPT 生成無窮無盡的答案 (用任何語言!)
// @description:zh-SG   从无所不知的 ChatGPT 生成无穷无尽的答案 (用任何语言!)
// @description:zh-TW   從無所不知的 ChatGPT 生成無窮無盡的答案 (用任何語言!)
// @author              Adam Lui
// @namespace           https://github.com/adamlui
// @version             2024.7.25
// @license             MIT
// @match               *://chatgpt.com/*
// @match               *://chat.openai.com/*
// @icon                https://media.chatgptinfinity.com/images/icons/infinity-symbol/black/icon48.png?fa77d27
// @icon64              https://media.chatgptinfinity.com/images/icons/infinity-symbol/black/icon64.png?fa77d27
// @compatible          chrome
// @compatible          firefox
// @compatible          edge
// @compatible          opera
// @compatible          brave
// @compatible          vivaldi
// @compatible          waterfox
// @compatible          librewolf
// @compatible          ghost
// @compatible          qq
// @compatible          whale
// @compatible          kiwi
// @require             https://cdn.jsdelivr.net/npm/@kudoai/chatgpt.js@3.0.1/dist/chatgpt.min.js#sha256-jCJMPu044aK37jtC2wMMKnNgHbXJ5Pm9ZdIqDERob7k=
// @connect             cdn.jsdelivr.net
// @connect             greasyfork.org
// @grant               GM_setValue
// @grant               GM_getValue
// @grant               GM_registerMenuCommand
// @grant               GM_unregisterMenuCommand
// @grant               GM_openInTab
// @grant               GM_xmlhttpRequest
// @grant               GM.xmlHttpRequest
// @noframes
// @homepageURL         https://www.chatgptinfinity.com
// @supportURL          https://support.chatgptinfinity.com
// @contributionURL     https://github.com/sponsors/adamlui
// @downloadURL https://raw.githubusercontent.com/FiorenMas/Userscripts/release/release/ChatGPT20Infinity20E2889E.user.js
// @updateURL https://raw.githubusercontent.com/FiorenMas/Userscripts/release/release/ChatGPT20Infinity20E2889E.meta.js
// ==/UserScript==
(async()=>{const e={appName:"ChatGPT Infinity",appSymbol:"∞",keyPrefix:"chatGPTinfinity",gitHubURL:"https://github.com/adamlui/chatgpt-infinity",greasyForkURL:"https://greasyfork.org/scripts/465051-chatgpt-infinity",mediaHostURL:"https://media.chatgptinfinity.com/",latestAssetCommitHash:"ce1772f"};e.updateURL=e.greasyForkURL.replace("https://","https://update.").replace(/(\d+)-?([a-zA-Z-]*)$/,((e,t,n)=>`${t}/${n||"script"}.meta.js`)),e.supportURL="https://support.chatgptinfinity.com",e.assetHostURL=e.gitHubURL.replace("github.com","cdn.jsdelivr.net/gh")+`@${e.latestAssetCommitHash}/`,e.userLanguage=chatgpt.getUserLanguage(),function(...t){t.forEach((t=>{e[t]=GM_getValue(e.keyPrefix+"_"+t,!1)}))}("autoScrollDisabled","autoStart","replyInterval","replyLanguage","replyTopic","toggleHidden"),e.replyLanguage||s("replyLanguage",e.userLanguage),e.replyTopic||s("replyTopic","ALL"),e.replyInterval||s("replyInterval",7);const t="OrangeMonkey"==r()?GM_xmlhttpRequest:GM.xmlHttpRequest;let n={};const a=new Promise((n=>{const a=e.assetHostURL+"greasemonkey/_locales/",o=(e.userLanguage?e.userLanguage.replace("-","_"):"en")+"/";let i=a+o+"messages.json",s=0;t({method:"GET",url:i,onload:function o(l){try{const e=JSON.parse(l.responseText),t={};for(const n in e)"object"==typeof e[n]&&"message"in e[n]&&(t[n]=e[n].message);n(t)}catch(l){if(s++,3==s)return n({});i=e.userLanguage.includes("-")&&1==s?i.replace(/([^_]+_[^_]+)_[^/]*(\/.*)/,"$1$2"):a+"en/messages.json",t({method:"GET",url:i,onload:o})}}})}));if(!e.userLanguage.startsWith("en"))try{n=await a}catch(e){}const o=[],i={symbol:["❌","✔️"],word:["OFF","ON"],separator:"Tampermonkey"==r()?" — ":": "};if(await Promise.race([new Promise((e=>{!function t(){document.querySelector("[cif-extension-installed]")?e(!0):setTimeout(t,200)}()})),new Promise((e=>setTimeout((()=>e(!1)),1500)))]))return void GM_registerMenuCommand(i.symbol[0]+" "+(n.menuLabel_disabled||"Disabled (extension installed)"),(()=>{}));function s(t,n){GM_setValue(e.keyPrefix+"_"+t,n),e[t]=n}function l(e){window.open(e,"_blank","noopener")}function r(){try{return GM_info.scriptHandler}catch(e){return"other"}}function c(){const t=i.symbol[+e.infinityMode]+" "+(n.menuLabel_infinityMode||"Infinity Mode")+" ∞ "+i.separator+i.word[+e.infinityMode];o.push(GM_registerMenuCommand(t,(()=>{document.getElementById("infinity-toggle-label").click()})));const a=i.symbol[+e.autoStart]+" "+(n.menuLabel_autoStart||"Auto-Start")+i.separator+i.word[+e.autoStart];o.push(GM_registerMenuCommand(a,(()=>{s("autoStart",!e.autoStart),u((n.menuLabel_autoStart||"Auto-Start")+": "+i.word[+e.autoStart]),p()})));const l=i.symbol[+!e.toggleHidden]+" "+(n.menuLabel_toggleVis||"Toggle Visibility")+i.separator+i.word[+!e.toggleHidden];o.push(GM_registerMenuCommand(l,(()=>{s("toggleHidden",!e.toggleHidden),k.style.display=e.toggleHidden?"none":"flex",u((n.menuLabel_toggleVis||"Toggle Visibility")+": "+i.word[+!e.toggleHidden]),p()})));const r=i.symbol[+!e.autoScrollDisabled]+" "+(n.menuLabel_autoScroll||"Auto-Scroll")+i.separator+i.word[+!e.autoScrollDisabled];o.push(GM_registerMenuCommand(r,(()=>{s("autoScrollDisabled",!e.autoScrollDisabled),u((n.menuLabel_autoScroll||"Auto-Scroll")+": "+i.word[+!e.autoScrollDisabled]),p()})));const c="🌐 "+(n.menuLabel_replyLang||"Reply Language")+i.separator+e.replyLanguage;o.push(GM_registerMenuCommand(c,(()=>{for(;;){let t=prompt(`${n.prompt_updateReplyLang||"Update reply language"}:`,e.replyLanguage);if(null===t)break;if(!/\d/.test(t)){t=[2,3].includes(t.length)||t.includes("-")?t.toUpperCase():t.charAt(0).toUpperCase()+t.slice(1).toLowerCase(),s("replyLanguage",t||e.userLanguage),g((n.alert_replyLangUpdated||"Language updated")+"!",(n.appName||e.appName)+" "+(n.alert_willReplyIn||"will reply in")+" "+(t||n.alert_yourSysLang||"your system language")+"."),e.infinityMode&&h(),p();break}}})));const m=new RegExp("^("+(n.menuLabel_all||"all")+"|all|any|every)$","i"),y="🧠 "+(n.menuLabel_replyTopic||"Reply Topic")+i.separator+(m.test(e.replyTopic)?n.menuLabel_all||"all":function(e){const t=e.toLowerCase().split(" ");for(let e=0;e<t.length;e++)t[e]=t[e][0].toUpperCase()+t[e].slice(1);return t.join(" ")}(e.replyTopic));o.push(GM_registerMenuCommand(y,(()=>{const t=prompt((n.prompt_updateReplyTopic||"Update reply topic")+" ("+(n.prompt_orEnter||"or enter")+" 'ALL'):",e.replyTopic);if(null!==t){const a=t.toString();s("replyTopic",!t||m.test(a)?"ALL":a),g((n.alert_replyTopicUpdated||"Topic updated")+"!",(n.appName||e.appName)+" "+(n.alert_willAnswer||"will answer questions")+" "+(!t||m.test(a)?n.alert_onAllTopics||"on ALL topics":(n.alert_onTopicOf||"on the topic of")+" "+a)+"!"),e.infinityMode&&(chatgpt.stop(),document.getElementById("infinity-toggle-label").click(),setTimeout((()=>{document.getElementById("infinity-toggle-label").click()}),500)),p()}})));const f="⌚ "+(n.menuLabel_replyInt||"Reply Interval")+i.separator+e.replyInterval+"s";o.push(GM_registerMenuCommand(f,(async()=>{for(;;){const t=prompt(`${n.prompt_updateReplyInt||"Update reply interval (minimum 5 secs)"}:`,e.replyInterval);if(null===t)break;if(!isNaN(parseInt(t,10))&&parseInt(t,10)>4){s("replyInterval",parseInt(t,10)),g((n.alert_replyIntUpdated||"Interval updated")+"!",(n.appName||e.appName)+" "+(n.alert_willReplyEvery||"will reply every")+" "+t+" "+(n.unit_seconds||"seconds")+"."),e.infinityMode&&b(),p();break}}})));const L=`💡 ${n.menuLabel_about||"About"} ${n.appName||e.appName}`;o.push(GM_registerMenuCommand(L,d))}function p(){if("OrangeMonkey"!=r()){for(const e of o)GM_unregisterMenuCommand(e);c()}}function d(){const a=(/chatgpt-([\d.]+)\.min/.exec(GM_info.script.header)||[null,""])[1],o="font-size: 1.15rem",i="position: relative ; left: 3px",s="color: "+(chatgpt.isDarkMode()?"#c67afb":"#8325c4"),r=g(n.appName||e.appName,`<span style="${o}"><b>🏷️ <i>${n.about_version||"Version"}</i></b>: </span><span style="${i}">${GM_info.script.version}</span>\n<span style="${o}"><b>⚡ <i>${n.about_poweredBy||"Powered by"}</i></b>: </span><span style="${i}"><a style="${s}" href="https://chatgpt.js.org" target="_blank" rel="noopener">chatgpt.js</a>`+(a?" v"+a:"")+"</span>\n"+`<span style="${o}"><b>📜 <i>${n.about_sourceCode||"Source code"}</i></b>:</span>\n`+`<span style="position: relative ; left: 4px "><a href="${e.gitHubURL}" target="_blank" rel="nopener">`+e.gitHubURL+"</a></span>",[function(){!function(){const a=GM_info.script.version;t({method:"GET",url:e.updateURL+"?t="+Date.now(),headers:{"Cache-Control":"no-cache"},onload:t=>{const o=377,i=/@version +(.*)/.exec(t.responseText)[1];for(let t=0;t<4;t++){const s=parseInt(a.split(".")[t],10)||0,l=parseInt(i.split(".")[t],10)||0;if(s>l)break;if(l>s){const t=g((n.alert_updateAvail||"Update available")+"! 🚀",(n.alert_newerVer||"An update to")+" "+(n.appName||e.appName)+" "+`(v${i}) ${n.alert_isAvail||"is available"}!  <a target="_blank" rel="noopener" style="font-size: 0.7rem" href="`+e.gitHubURL+"/commits/main/greasemonkey/"+e.updateURL.replace(/.*\/(.*)meta\.js/,"$1user.js")+'"'+`> ${n.link_viewChanges||"View changes"}</a>`,(function(){GM_openInTab(e.updateURL.replace("meta.js","user.js")+"?t="+Date.now(),{active:!0,insert:!0})}),"",o);if(!e.userLanguage.startsWith("en")){const e=document.querySelector(`[id="${t}"]`).querySelectorAll("button");e[1].textContent=n.buttonLabel_update||"Update",e[0].textContent=n.buttonLabel_dismiss||"Dismiss"}return}}g((n.alert_upToDate||"Up-to-date")+"!",`${n.appName||e.appName} (v${a}) `+(n.alert_isUpToDate||"is up-to-date")+"!","","",o),d()}})}()},function(){l(e.supportURL)},function(){const t=chatgpt.alert((n.alert_choosePlatform||"Choose a Platform")+":","",[function(){l(e.greasyForkURL+"/feedback#post-discussion")},function(){l("https://www.producthunt.com/products/chatgpt-infinity/reviews/new")},function(){l("https://alternativeto.net/software/chatgpt-infinity/about/")}]),a=document.getElementById(t).querySelectorAll("button");a[0].style.display="none",a[1].textContent=a[1].textContent.replace(/\s/g,"")},function(){l("https://github.com/adamlui/chatgpt-apps")}],"",478);for(const e of document.getElementById(r).querySelectorAll("button"))/updates/i.test(e.textContent)?e.textContent="🚀 "+(n.buttonLabel_updateCheck||"Check for Updates"):/support/i.test(e.textContent)?e.textContent="🧠 "+(n.buttonLabel_getSupport||"Get Support"):/review/i.test(e.textContent)?e.textContent="⭐ "+(n.buttonLabel_leaveReview||"Leave a Review"):/apps/i.test(e.textContent)?e.textContent="🤖 "+(n.buttonLabel_moreApps||"More ChatGPT Apps"):e.style.display="none"}function u(t,n="",a="",o=""){const s=i.word.find((e=>t.includes(e)));s&&(t=t.replace(s,"")),chatgpt.notify(`${e.appSymbol} ${t}`,n,a,o||chatgpt.isDarkMode()?"":"shadow");const l=document.querySelectorAll(".chatgpt-notif"),r=l[l.length-1];if(s){const e=document.createElement("span");e.style.cssText="color: "+(s==i.word[0]?"#ef4848 ; text-shadow: rgba(255, 169, 225, 0.44) 2px 1px 5px":"#5cef48 ; text-shadow: rgba(255, 250, 169, 0.38) 2px 1px 5px"),e.append(s),r.append(e)}}function g(t="",n="",a="",o="",i=""){return chatgpt.alert(`${e.appSymbol} ${t}`,n,a,o,i)}async function m(){const t=document.querySelector("nav");t.contains(k)||t.insertBefore(k,t.children[1]),k.style.flexGrow="unset",k.style.paddingLeft="8px";const n=document.getElementById("infinity-toggle-navicon");n&&(n.src=`${e.mediaHostURL}images/icons/infinity-symbol/${chatgpt.isDarkMode()?"white":"black"}/icon32.png?${e.latestAssetCommitHash}`)}function y(){const t=document.getElementById("infinity-toggle-navicon")||document.createElement("img");t.id="infinity-toggle-navicon",t.style.width=t.style.height="1.25rem",t.style.marginLeft="2px",t.style.marginRight="4px";const a=document.getElementById("infinity-toggle-input")||document.createElement("input");a.id="infinity-toggle-input",a.type="checkbox",a.disabled=!0,a.style.display="none",a.checked=e.infinityMode;const o=document.getElementById("infinity-switch-span")||document.createElement("span");o.id="infinity-switch-span";const i={position:"relative",left:(chatgpt.browser.isMobile()?211:_?w?147:154:160)+"px",backgroundColor:a.checked?"#ccc":"#AD68FF",bottom:(_?L||!w?.05:0:-.15)+"em",width:"30px",height:"15px","-webkit-transition":".4s",transition:"0.4s",borderRadius:"28px"};Object.assign(o.style,i);const s=document.getElementById("infinity-toggle-knob-span")||document.createElement("span");s.id="infinity-toggle-knob-span";const l={position:"absolute",left:"3px",bottom:(L&&!_?.075:.055)+"em",width:"13px",height:"13px",content:'""',borderRadius:"28px",transform:a.checked?"translateX(0)":"translateX(13px) translateY(0)",backgroundColor:"white","-webkit-transition":"0.4s",transition:"0.4s"};Object.assign(s.style,l),o.append(s);const r=document.getElementById("infinity-toggle-label")||document.createElement("label");r.id="infinity-toggle-label",_||(r.style.fontSize="0.875rem",r.style.fontWeight=600),r.style.marginLeft=`-${_?41:23}px`,r.style.cursor="pointer",r.style.width=(chatgpt.browser.isMobile()?201:w?145:148)+"px",r.style.overflow="hidden",r.style.textOverflow="ellipsis",r.innerText=(n.menuLabel_infinityMode||"Infinity Mode")+" "+(a.checked?n.state_enabled||"enabled":n.state_disabled||"disabled");for(const e of[t,a,o,r])k.append(e);k.style.display=e.toggleHidden?"none":"flex",setTimeout((()=>{o.style.backgroundColor=a.checked?"#ad68ff":"#ccc",o.style.boxShadow=a.checked?"2px 1px 9px #d8a9ff":"none",s.style.transform=a.checked?"translateX(13px) translateY(0)":"translateX(0)"}),1)}c();const f={async activate(){if(u((n.menuLabel_infinityMode||"Infinity Mode")+": ON"),chatgpt.browser.isMobile()&&chatgpt.sidebar.isOn()&&chatgpt.sidebar.hide(),!new URL(document.location).pathname.startsWith("/g/"))try{chatgpt.startNewChat()}catch(e){return}setTimeout((()=>{chatgpt.send("Generate a single random question"+(e.replyLanguage?" in "+e.replyLanguage:"")+" on "+("ALL"==e.replyTopic?"ALL topics":"the topic of "+e.replyTopic)+" then answer it. Don't type anything else.")}),500),await chatgpt.isIdle(),e.infinityMode&&!f.isActive&&(f.isActive=setTimeout(f.continue,1e3*parseInt(e.replyInterval,10)))},async continue(){if(chatgpt.send("Do it again."),!e.autoScrollDisabled)try{chatgpt.scrollToBottom()}catch(e){}await chatgpt.isIdle(),f.isActive&&(f.isActive=setTimeout(f.continue,1e3*parseInt(e.replyInterval,10)))},deactivate(){chatgpt.stop(),clearTimeout(f.isActive),f.isActive=null,document.getElementById("infinity-toggle-input").checked=!1,u((n.menuLabel_infinityMode||"Infinity Mode")+": OFF"),e.infinityMode=!1},toggle(){e.infinityMode?f.activate():f.deactivate()}};function h(){chatgpt.stop(),document.getElementById("infinity-toggle-label").click(),setTimeout((()=>{document.getElementById("infinity-toggle-label").click()}),500)}async function b(){clearTimeout(f.isActive),f.isActive=null,await chatgpt.isIdle(),e.infinityMode&&!f.isActive&&(f.isActive=setTimeout(f.continue,1e3*parseInt(e.replyInterval,10)))}await Promise.race([chatgpt.isLoaded(),new Promise((e=>setTimeout(e,5e3)))]),await chatgpt.sidebar.isLoaded();const L=chatgpt.browser.isFirefox(),w=document.documentElement.className.includes(" "),_=chatgpt.getNewChatLink();void 0!==document.hidden&&(document.onvisibilitychange=()=>{e.infinityMode&&(document.getElementById("infinity-toggle-label")?document.getElementById("infinity-toggle-label").click():f.deactivate(),p())});const v=20240724;let x=document.getElementById("tweaks-style");(!x||parseInt(x.getAttribute("last-updated"),10)<v)&&(x||(x=document.createElement("style"),x.id="tweaks-style",x.setAttribute("last-updated",v.toString()),document.head.append(x)),x.innerText=(chatgpt.isDarkMode()?".chatgpt-modal > div { border: 1px solid white }":"")+".chatgpt-modal button {font-size: 0.77rem ; text-transform: uppercase ;border-radius: 0 !important ; padding: 5px !important ; min-width: 102px }.chatgpt-modal button:hover { transform: scale(1.055) }.modal-buttons { margin-left: -13px !important }* { scrollbar-width: thin }.sticky div:active, .sticky div:focus {transform: none !important }");const k=document.createElement("div");if(k.style.height="37px",k.style.margin="2px 0",k.style.userSelect="none",k.style.cursor="pointer",y(),_){const e=_.querySelector("div:first-child"),t=_.querySelector("div:nth-child(2)");k.classList.add(..._.classList,...t.classList),k.querySelector("img")?.classList.add(...e.classList)}if(m(),k.onclick=()=>{const t=document.getElementById("infinity-toggle-input");t.checked=!t.checked,e.infinityMode=t.checked,y(),p(),f.toggle()},e.autoStart){const t=document.getElementById("infinity-toggle-input");t?t.parentNode.click():(f.activate(),e.infinityMode=!0,p())}new MutationObserver((e=>{e.forEach((e=>{"childList"==e.type&&e.addedNodes.length&&m()}))})).observe(document.documentElement,{childList:!0,subtree:!0})})();